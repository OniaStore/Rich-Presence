Citizen.CreateThread(function()
    while true do
        SetDiscordAppId(123456789) -- Remplacez 123456789 par l'ID de votre application Discord

        SetDiscordRichPresenceAsset('asset_name') -- Remplacez 'asset_name' par le nom de votre asset Discord
        SetDiscordRichPresenceAssetText('Nom du serveur RP') -- Remplacez 'Nom du serveur RP' par le nom de votre serveur

        print("^4By Shyda | Onia Store")

        -- Bouton Discord --
        SetDiscordRichPresenceAction(0, "Discord", "https://discord.gg/invite_code") -- Remplacez 'invite_code' par le lien d'invitation de votre serveur Discord

        -- Deuxième Bouton (Se Connecter) --
        SetDiscordRichPresenceAction(1, "Se Connecter", "fivem://connect/ip:port") -- Remplacez 'ip:port' par l'IP et le port de votre serveur

        players = {}
        for i = 0, 255 do
            if NetworkIsPlayerActive(i) then
                table.insert(players, i)
            end
        end

        -- Affichage du nombre de joueurs --
        SetRichPresence(GetPlayerName(PlayerId()) .. " - " .. #players .. "/32") -- Remplacez 32 par le nombre de slots de votre serveur

        Citizen.Wait(60000) -- Attendre 60 secondes avant de mettre à jour la rich presence
    end
end)

-- By Shyda | Onia Store --
