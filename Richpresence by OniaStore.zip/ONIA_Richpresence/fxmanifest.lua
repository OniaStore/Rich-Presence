fx_version 'cerulean'
games {'gta5'}

author 'Shyda'
description 'RichPresence'
version '1.0.0'

lua54 'yes'

client_scripts {
    'richpresence_oniastore.lua',
}